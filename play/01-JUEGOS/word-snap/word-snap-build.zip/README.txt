WORD SNAP - BUILD DE PRODUCCION V6
===================================

DESTINO: https://play.naturalbe.com.co
RUTA EN SERVIDOR: public_html/play/

INSTRUCCIONES RAPIDAS:
----------------------

1. Subir TODOS los archivos de esta carpeta a Hostinger
2. Colocarlos en: public_html/play/
3. Verificar que index.html esté en la raíz de play/
4. Abrir https://play.naturalbe.com.co
5. Probar el juego

ARCHIVOS INCLUIDOS: 16
----------------------
- index.html (página principal)
- marathon.html (modo maratón)
- pro-styles.css (estilos)
- 13 archivos JavaScript (lógica del juego)

DOCUMENTACION COMPLETA:
-----------------------
Ver DEPLOY-HOSTINGER.md para instrucciones detalladas

SOPORTE:
--------
Desarrollado por: Kiro AI Assistant
Fecha: 2025-11-27
Versión: V6 Production Build

¡LISTO PARA SUBIR A HOSTINGER!
